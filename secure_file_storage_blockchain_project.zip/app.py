
from flask import Flask, request, render_template, redirect
import hashlib, json, os

app = Flask(__name__)
CHAIN_FILE = "blockchain.json"

def load_chain():
    if not os.path.exists(CHAIN_FILE):
        return []
    with open(CHAIN_FILE, "r") as f:
        return json.load(f)

def save_chain(chain):
    with open(CHAIN_FILE, "w") as f:
        json.dump(chain, f, indent=2)

def hash_file(file_bytes):
    return hashlib.sha256(file_bytes).hexdigest()

@app.route("/", methods=["GET","POST"])
def index():
    if request.method == "POST":
        file = request.files["file"]
        data = file.read()
        file_hash = hash_file(data)

        chain = load_chain()
        block = {
            "index": len(chain)+1,
            "filename": file.filename,
            "hash": file_hash
        }
        chain.append(block)
        save_chain(chain)
        return redirect("/chain")

    return render_template("index.html")

@app.route("/chain")
def chain():
    chain = load_chain()
    return render_template("chain.html", chain=chain)

if __name__ == "__main__":
    app.run(debug=True)
