
# Secure File Storage System Using Blockchain

Simple demo showing how file hashes can be stored in a blockchain-style ledger.

## Features
- Upload files
- SHA-256 hash generation
- Append-only blockchain JSON record
- Verify file integrity

## Run

pip install flask
python app.py

Then open http://127.0.0.1:5000
